<div className="flex items-center w-[52.18%] relative grow mt-[530px] mx-auto mb-[5px]">
                <div className="flex flex-col relative basis-[41px]">
                  <img
                    src={require('../media/87c2dd63aa6a5b1cd020ec9a1eb2a1c2.png')}
                    alt="alt text"
                    className="w-[41px] h-auto aspect-[1.37] align-top object-cover object-[center_center] relative min-w-[41px]"
                  />
                </div>
                <div className="basis-[118px]" />
                <div className="flex items-center justify-center font-normal text-sm font-Poppins text-white text-center tracking-[0px] relative shrink-0 basis-auto min-w-[28px] my-[5px] mx-0">
                  1 / 4
                </div>
                <div className="basis-[118px]" />

                <div className="flex flex-col relative overflow-hidden basis-[41px] min-h-[30px]">
                  <div className="bg-[rgb(116,116,184)] rounded-[1px] w-[19px] h-0.5 relative min-w-[19px] mt-[15px] mr-0 mb-0 ml-2" />
                </div>
              </div>