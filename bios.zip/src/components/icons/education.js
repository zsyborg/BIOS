import * as React from 'react';
import eduicon from '../../media/my institution.svg';
function Education() {
  // const [anchorElNav, setAnchorElNav] = React.useState(null);
  // const [anchorElUser, setAnchorElUser] = React.useState(null);

  return (
    
    <img src={eduicon} className='w-20' />
    

  );
}
export default Education;
